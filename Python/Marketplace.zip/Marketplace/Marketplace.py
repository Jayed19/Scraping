#IMPORTS
import json
from seleniumwire import webdriver

from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep
import time
import os
import traceback
import requests
from datetime import datetime, timedelta
from selenium.webdriver.support.ui import WebDriverWait

from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select


#VARIABLES
username = "manager@knsmobility.com"
password = "Knspassword2021!"

def open_ff(headless):
        print('\nopen firefox:')
        options = Options()
        options.headless = headless
        #options.headless = False
        driver = webdriver.Firefox(options=options, executable_path=r'C:\geckodriver', service_log_path=os.devnull)
        #driver = webdriver.Firefox(options=options, executable_path='geckodriver.exe', service_log_path=os.devnull)
    
        #maximize the firefox window
        if headless == True:
            driver.set_window_size(1920, 4000)
        else:
            driver.maximize_window()
        print('  opened')
        sleep(2)
        return driver

def login(driver):
    print('\nlogin')
    url='https://mtm.mtmlink.net'
    print('  open page:',url)
    
    driver.get(url)
    sleep(50)
    print('    opened\n  insert password and navigate to menu')
    
    driver.find_element(By.XPATH, '//input[@id="LoginEmail"]').send_keys(username)
 
    driver.find_element(By.XPATH, '//input[@id="LoginPassword"]').send_keys(password)
    sleep(0.5)
    
    driver.find_element(By.XPATH, '//button[@id="SignInButton"]').click()
    sleep(20)
    print('  logged in')
def navigate_to_marketplace(driver):
    driver.get('https://pe.mtmlink.net/#/marketplace')
    sleep(20)

def collect_and_create_json(driver):
    print('\nCollect json:')
    driver.find_element(By.XPATH, '//div[@class="ant-select MarketplaceFilter_submitSearchSelect__2_ovX ant-select-single ant-select-show-arrow ant-select-show-search"]').click()
    sleep(2)
    print("click on the Mode done")
    WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.XPATH, "//div[@class='ant-select-item-option-content' and text()='Cab']"))).click()
    print("Cab Select Done")
    sleep(2)
    driver.find_element(By.XPATH, '//button[@class="mtm-btn"]').click()
    sleep(20)
    print("Apply Filter button Click Done")
    
    for request in driver.requests:
        if ('https://api-ua.mtmlink.net/provider/marketplace/v1/trips' in request.url) and ('POST' == request.method):
            json_response=json.loads(request.response.body.decode('utf-8'))
            #print(json_response)
            #head=request.headers
            #print(head)
            print('  collected')

            
            if len(json_response)>0:
                print('  Number of entry found:',len(json_response))
                file_name=time.strftime("%Y-%m-%d_%Hm_%Mh_%Ss",time.localtime())+"-new-2"+".json"
                print('\nWrite json to file:',file_name)
             
                file=open(file_name,'w', encoding="utf8")
                file.write(json.dumps(json_response, indent=4, ensure_ascii=False))
                file.close
                print('  done')



def main():
    
    driver=open_ff(True)
    
    login(driver)
    navigate_to_marketplace(driver)
    try:
        collect_and_create_json(driver)
    except:
        print(traceback.format_exc())
    driver.close()
    
if __name__ == "__main__":
    startTime = time.perf_counter()
    main()
    endTime = time.perf_counter()
    print(f"\nDownloaded the json in {endTime - startTime:0.4f} seconds")
            
            

        
   